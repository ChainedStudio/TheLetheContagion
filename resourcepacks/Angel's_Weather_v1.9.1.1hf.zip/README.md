# Angel's Weather

## Selya's Gratitude

With sincere gratitude for choosing Angel's Font, we are honored by Her Majesty Selya’s blessing ~ one of her divine mirror stigmata creations, bestowed upon us.

## What is a Stigmata Mirror?

A Stigmata Mirror is a creation of Selya, the Divine Seamstress of Realities. This mirror represents a fragment of reality itself. The more pieces you assemble, the larger the image becomes. What the full image reveals is a reflection of time, beauty, and your own place within it ~ a living, evolving part of the world. 

She is the embodiment of light, the creation serves as the mirror, and you are its reflection.

## This Stigmata Mirror Features

**Core Features**

* **Rain** – pleasing to behold, bringing ease and calm to your vision
* **Snow** – delicate and pleasant, with refined detail
* **Realistic Rain Sounds** – authentic recordings that create a dynamic, immersive atmosphere
* **Realistic Thunder Sounds** – genuine thunder, balanced to be gentle on the ears
* **Rain Splash Sounds** – adds depth and presence to your surroundings
* **Ambience Sounds** – enriches and elevates the overall experience
* **Animated Rain Splashes** – stylized effects that feel vivid and alive
* **Handcrafted Cloud Design** – each cloud unique, as if carrying its own story

**+Features - Using Polytone Mod**

* **Reworked Biome Vegetation Color Palettes** – a revitalized, reimagined look for your world
* **Biome Fog Colors** – unique fog hues for overworld biomes and caves
* **Biome Sky Colors** – designed in harmony with fog for a seamless atmosphere
* **Cloud Shading** – gentle shading that adds subtle depth to the clouds
* **Water Colors** – deeper shades in vast waters, lighter tones in shallow areas
* **Rain Particle System** – refined visuals with distinct states for rain and thunderstorms
* **Wind System** – influences rain and fog, adding subtle yet noticeable movement
* **Space-Aware Fog** – fog adapts to your position, interacting dynamically with the weather

### ⚠️ +Features (Polytone Mod Required)
The Polytone mod unlocks additional +Features for an enriched experience. Without it, only the core features are available.

## Need Help?
Should you encounter any issues, require compatibility support, or wish to share suggestions, you are warmly invited to join our Discord server.
https://discord.gg/t7JJPyxJ6k

## Donations?

Ko-Fi:
https://ko-fi.com/liminalangel


~ May all the beauty be blessed, with you counted among its radiance.